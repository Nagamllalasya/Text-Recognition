# TextRecognitionApp
 
